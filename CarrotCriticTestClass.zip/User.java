package carrotcritictest.carrotcritictest;

public class User {

	private String password = "helloworld123";
	
	public boolean checkPassword(String pass) {
		if (password.equals(pass))
		return true;
		
		else 
			return false;
	}
}