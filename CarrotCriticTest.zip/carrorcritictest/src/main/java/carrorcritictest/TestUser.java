package carrorcritictest;

import static org.junit.Assert.assertTrue;
import org.junit.Test;
//import org.junit.Ignore;

public class TestUser {

	@Test
	public void testCheckpass() {
		User user = new User();
		assertTrue(user.checkPassword("helloworld123"));
	}
	@Test
	public void testCheckfail() {
		User user = new User();
		assertTrue(user.checkPassword("HelloWorld12"));
	}
}
